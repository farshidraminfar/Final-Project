$(document).ready(function() {
  $('#photos img').draggable({
    revert : "valid",
  	
  });
  $('#photos2 img').draggable({
    revert : "valid",
  	
  });
	
	$('#trashcan').droppable({
    activeClass : 'highlight',
  	drop : function (event, ui) {
  		ui.helper.hide('explode');
  		$(this).attr('src','images/trashcan-full-icon.png');
  	}
  });
	
}); // End Ready